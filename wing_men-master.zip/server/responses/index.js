module.exports = {
    ok: require('./ok'),
    serverError: require('./serverError'),
    forbidden: require('./forbidden'),
    success: require('./success')
};
