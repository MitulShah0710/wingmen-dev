const portNumber = 3080;
const jwtSecretKey = 'iAmSecretKey';
const cryptSecretKey = 'wingmen&&^^(())';
const fcmDriverKey = 'AAAAwn1OWTk:APA91bFVv1fo4Ag3VxTMFfn69PmVOTrUf_zMt8YtNDWGsiCIUaOAUcf6vKsYMhw4WEgwrAcYZN_pbkICsT3TvzoQg34tF1lcVyArqFNgyx3raLC8-0pcn6cgjVJpyz1Bk9KEP9qTJVZU';
const fcmCustomerKey='AAAAwn1OWTk:APA91bFVv1fo4Ag3VxTMFfn69PmVOTrUf_zMt8YtNDWGsiCIUaOAUcf6vKsYMhw4WEgwrAcYZN_pbkICsT3TvzoQg34tF1lcVyArqFNgyx3raLC8-0pcn6cgjVJpyz1Bk9KEP9qTJVZU';

const apnCertificate={
    apnUserCertificate:'AAAAwn1OWTk:APA91bFVv1fo4Ag3VxTMFfn69PmVOTrUf_zMt8YtNDWGsiCIUaOAUcf6vKsYMhw4WEgwrAcYZN_pbkICsT3TvzoQg34tF1lcVyArqFNgyx3raLC8-0pcn6cgjVJpyz1Bk9KEP9qTJVZU',
    apnDriverCertificate:'AAAAkYX5rUk:APA91bHi4IDH7vqbfHO6Tfk3SRVmeRgOKJ_sDat8YICCVtmYIF89F1ps85xmPEzXl89DwPGUDHGpuMCMygux-cPUweOamwLJVHic9T8JvY2PixQzAKa8ig9Mu9t8VvlNor2IybknGjHm',
    gateway:'gateway.push.apple.com',
    sandBoxGateway:'gateway.sandbox.push.apple.com'
}
const salesTax = 10;
const twilioCredentials={
    accountSid:"AC507a867549ab6a93e290d876a84e7dfa",
    authToken:"8aaf1ff7b040d95bde4e86666d04bd98",
    senderNumber:"+16312021047"
};
const stripKey='sk_live_a3RneGTgejl7yIbQHfGlEXQx00dyCUjTEl';
const stripKeyTest='sk_test_ZkUbe22tTR7xyUMR1vpYfV5j00ywBypeIY';
const stripKeyLive='sk_live_a3RneGTgejl7yIbQHfGlEXQx00dyCUjTEl';
const stripPub_live_key ="pk_live_dsqAdOeWLw4GZDhfiBKvUDGt00bmfhGf1r";

const sinchCredentials={
    url:'https://verificationapi-v1.sinch.com/verification/v1/verifications',
    key:"0d5464e9-be86-430a-83dc-13da49ae23c4",
    secret:"mAGKg/AeKUakWQ++HtWrOg==",
    servicePlanId:"d9deba911f0b43238bf965f459766246",
    apiToken:"Bearer 71eda8aba0dc4766865c9f6df75c3a14",
    restApiUrl:"https://us.sms.api.sinch.com/xms/v1/d9deba911f0b43238bf965f459766246/batches",
    fromNumber:"+12072180666"
};
module.exports = {
    port: portNumber,
    SecretKey: jwtSecretKey,
    cryptHash: cryptSecretKey,
    fcmDriverKey: fcmDriverKey,
    fcmCustomerKey:fcmCustomerKey,
    tax: salesTax,
    apnCertificate:apnCertificate,
    twilioCredentials:twilioCredentials,
    stripKey:stripKeyTest,
    sinchCredentials:sinchCredentials
};
