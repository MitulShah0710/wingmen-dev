const Controller = require('../controllers/index');
const Authorization = require('../../polices/index');
const Upload = require('../../services/FileUploadService');
const express = require('express');
const router = express.Router();

/*
ADMIN API'S
*/
router.post('/signUp', Controller.AdminController.register);
router.post('/signIn', Controller.AdminController.login);
router.post('/logout', Authorization.isUserAuth, Controller.AdminController.logout);
router.post('/getProfile', Authorization.isUserAuth, Controller.AdminController.getProfile);
router.post('/updateAdminProfile', Authorization.isUserAuth, Controller.AdminController.updateAdminProfile);
router.post('/changePassword', Authorization.isUserAuth, Controller.AdminController.changePassword);
router.post('/getAllVehicle', Authorization.isUserAuth, Controller.AdminController.getAllVehicle);
router.post('/forgotPassword', Controller.AdminController.forgotPassword);
router.post('/forgotChangePassword', Controller.AdminController.forgotChangePassword);
router.post('/uploadFile', Authorization.isUserAuth, Upload.driverDocument.single('image'), Controller.AdminController.uploadFile);
/*
DASHBOARD API'S
*/
router.get('/getDashboardCount', Authorization.isUserAuth, Controller.AdminController.getDashboardCount);
/*
USER API'S
*/

router.post('/registerUser', Authorization.isUserAuth, Upload.user.single('image'), Controller.AdminController.registerUser);
router.post('/updateUser', Authorization.isUserAuth, Upload.user.single('image'), Controller.AdminController.upadateUser)
router.post('/getAllUsers', Authorization.isUserAuth, Controller.AdminController.getAllUsers);
router.post('/getAllVehicleUser', Authorization.isUserAuth, Controller.AdminController.getAllVehicleUser);
router.post('/verifyBlockUnBlockDeltedUser', Authorization.isUserAuth, Controller.AdminController.verifyBlockUnBlockDeltedUser)
router.get('/exportDriverCsv', Controller.AdminController.exportDriverCsv);

/*
VEHICLE API'S
*/
router.post('/addVehicleType', Authorization.isUserAuth, Controller.AdminController.addVehicleType);
router.post('/editVehicleType', Authorization.isUserAuth, Controller.AdminController.editVehicleType);
router.post('/blockUnblockDeleteVehicleType', Authorization.isUserAuth, Controller.AdminController.blockUnblockDeleteVehicleType);
router.get('/getVehicleType', Authorization.isUserAuth, Controller.AdminController.getVehicleType);
/*
SERVICE TYPE API'S
*/
router.post('/addServiceType', Authorization.isUserAuth, Upload.serviceType.single('image'), Controller.AdminController.addServiceType);
router.post('/editServiceType', Authorization.isUserAuth, Upload.serviceType.single('image'), Controller.AdminController.editServiceType);
router.post('/blockUnblockDeleteServiceType', Authorization.isUserAuth, Controller.AdminController.blockUnblockDeleteServiceType);
router.get('/getServiceType', Authorization.isUserAuth, Controller.AdminController.getServiceType);
/*
BOOKING API'S
*/
router.post('/getAllBooking', Authorization.isUserAuth, Controller.AdminController.getAllBooking);
router.put('/editBooking/:id', Authorization.isUserAuth, Controller.AdminController.editBooking);
router.post('/getBookingDetails', Authorization.isUserAuth, Controller.AdminController.getBookingDetails);
router.post('/acceptedBookingStatus', Authorization.isUserAuth, Controller.AdminController.acceptedBookingStatus);
router.post('/acceptedCancelCompleteEventBookingStatus', Authorization.isUserAuth, Controller.AdminController.acceptedCancelCompleteEventBookingStatus);
router.get('/exportBookingCsv', Controller.AdminController.exportBookingCsv);
router.post('/createBooking', Controller.AdminController.createBooking);
/*
NOTIFICATION API'S
*/
router.get('/getAllNotification', Authorization.isUserAuth, Controller.AdminController.getAllNotification);
router.post('/clearNotification', Authorization.isUserAuth, Controller.AdminController.clearNotification);
router.post('/clearAllNotification', Authorization.isUserAuth, Controller.AdminController.clearAllNotification);
/*
PROMO CODE API'S
*/
router.post('/addPromoCode', Authorization.isUserAuth, Controller.AdminController.addPromo);
router.post('/editPromoCode', Authorization.isUserAuth, Controller.AdminController.editPromoCode);
router.post('/deleteBlockPromoCode', Authorization.isUserAuth, Controller.AdminController.deleteBlockPromoCode);
router.get('/getAllPromoCode', Authorization.isUserAuth, Controller.AdminController.getAllPromo);

/*
REVENUE API'S
*/
router.post('/getRevenue', Authorization.isUserAuth, Controller.AdminController.getRevenue);
/*
DRIVER API'S
*/
router.post('/driverRegister', Authorization.isUserAuth, Upload.driver.single('image'), Controller.AdminController.driverRegister);
router.post('/updateDriverProfile', Authorization.isUserAuth, Upload.driver.single('image'), Controller.AdminController.updateDriverProfile);
router.post('/updateDocuments', Authorization.isUserAuth, Controller.AdminController.updateDocuments);
router.post('/getAllDrivers', Authorization.isUserAuth, Controller.AdminController.getAllDrivers);
router.post('/verifyBlockUnBlockDeltedDriver', Authorization.isUserAuth, Controller.AdminController.verifyBlockUnBlockDeltedDriver)
router.post('/getAllVehicleDriver', Authorization.isUserAuth, Controller.AdminController.getAllVehicleDriver);
router.post('/getAllAvailableDriver', Authorization.isUserAuth, Controller.AdminController.getAllAvailableDriver);
router.post('/addVehicle', Authorization.isUserAuth,Upload.vehicle.single('vehicleImage'), Controller.AdminController.addVehicle);
/*
TRANSMISSION TYPE API'S
*/
router.post('/addTransmissionType', Authorization.isUserAuth, Controller.AdminController.addTransmissionType);
router.post('/editTransmissionType', Authorization.isUserAuth, Controller.AdminController.editTransmissionType);
router.post('/blockUnblockDeleteTransmissionType', Authorization.isUserAuth, Controller.AdminController.blockUnblockDeleteTransmissionType);
router.get('/getTransmissionType', Authorization.isUserAuth, Controller.AdminController.getTransmissionType);
/*
APPVERSION API'S
*/
router.post('/setAppVersion', Authorization.isUserAuth, Controller.AdminController.setAppVersion);
router.get('/getAppVersion', Controller.AdminController.getAppVersion);
/*
TEAM API'S
*/
router.post('/addTeam', Authorization.isUserAuth, Controller.AdminController.addTeam);
router.post('/editTeam', Authorization.isUserAuth, Controller.AdminController.editTeam);
router.post('/blockUnblockDeleteTeam', Authorization.isUserAuth, Controller.AdminController.blockUnblockDeleteTeam);
router.get('/getTeam', Authorization.isUserAuth, Controller.AdminController.getTeam);
/*
EVENT TYPE API'S
*/
router.post('/addEventType', Authorization.isUserAuth, Controller.AdminController.addEventType);
router.post('/editEventType', Authorization.isUserAuth, Controller.AdminController.editEventType);
router.post('/blockUnblockDeleteEventType', Authorization.isUserAuth, Controller.AdminController.blockUnblockDeleteEventType);
router.get('/getEventType', Authorization.isUserAuth, Controller.AdminController.getEventType);

router.post('/assignCoDriver', Authorization.isUserAuth, Controller.AdminController.assignCoDriver);

/*
STATE API'S
*/
router.post('/addState', Authorization.isUserAuth, Controller.AdminController.addState);
router.post('/editState', Authorization.isUserAuth, Controller.AdminController.editState);
router.post('/blockUnblockDeleteState', Authorization.isUserAuth, Controller.AdminController.blockUnblockDeleteState);
router.get('/getState', Authorization.isUserAuth, Controller.AdminController.getState);
router.post('/getContactUs', Authorization.isUserAuth, Controller.AdminController.getContactUs);
router.post('/sendBulkNotification', Authorization.isUserAuth, Controller.AdminController.sendBulkNotification);

module.exports = router;
