module.exports = {
    UserRoutes: require('./userRotues'),
    AdminRoutes: require('./AdminRoutes'),
    DriverRoutes: require('./DriverRoutes')
};
