module.exports = {
    isUserValidate: require('./isUserValidate'),
    isAdminValidate: require('./isAdminValid'),
    isDriverValid: require('./isDriverValid')
};
